oi, aqui é o felipe kraft, 
fico muito contente que tenha se interessado pelo nosso projeto
fizemos uma espécie de relógio pomodoro com recompensas customizáveis 
para você poder ser organizar melhor na hora de estudar ! 

É isso, obrigado e espero que lhe seja útil.